import 'dart:js_interop';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:js/js.dart';

// JavaScript interop for Google Maps
@JS()
@anonymous
class MapOptions {
  external factory MapOptions({
    LatLng center,
    int zoom,
    bool mapTypeId,
  });

  external LatLng get center;
  external int get zoom;
  external bool get mapTypeId;
}

@JS()
@anonymous
class LatLng {
  external factory LatLng(double lat, double lng);
  external double get lat;
  external double get lng;
}

@JS()
@anonymous
class MarkerOptions {
  external factory MarkerOptions({
    LatLng position,
    String title,
    Map map,
  });

  external LatLng get position;
  external String get title;
  external Map get map;
}

@JS()
class Map {
  external Map(HtmlDivElement element, MapOptions options);
  external void setCenter(LatLng center);
  external void setZoom(int zoom);
  external Marker addMarker(MarkerOptions options);
  external void addEventListener(String event, Function callback);
}

@JS()
class Marker {
  external Marker(MarkerOptions options);
}

@JS()
class google {
  external static Maps get maps;
}

@JS()
class Maps {
  external Map get Map;
  external Marker get Marker;
  external LatLng get LatLng;
}

@JS('document')
external HtmlDocument get document;

@JS()
@anonymous
class HtmlDivElement {
  external HtmlDivElement createElement(String tagName);
}

@JS()
class HtmlDocument {
  external HtmlDivElement createElement(String tagName);
}

class WebGoogleMap extends StatefulWidget {
  final LatLng initialPosition;
  final Function(LatLng)? onDestinationSelected;
  final Set<WebMarker>? markers;

  const WebGoogleMap({
    super.key,
    required this.initialPosition,
    this.onDestinationSelected,
    this.markers,
  });

  @override
  State<WebGoogleMap> createState() => _WebGoogleMapState();
}

class _WebGoogleMapState extends State<WebGoogleMap> {
  Map? _map;
  final GlobalKey _mapKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeMap();
    });
  }

  void _initializeMap() {
    if (kIsWeb) {
      _loadGoogleMaps();
    }
  }

  void _loadGoogleMaps() {
    // Create map container
    final mapContainer = document.createElement('div');
    mapContainer.style.width = '100%';
    mapContainer.style.height = '100%';

    // Initialize Google Maps
    final mapOptions = MapOptions(
      center: LatLng(widget.initialPosition.latitude, widget.initialPosition.longitude),
      zoom: 15,
    );

    _map = google.maps.Map(mapContainer, mapOptions);

    // Add click listener for destination selection
    if (widget.onDestinationSelected != null) {
      _map!.addEventListener('click', allowInterop((event) {
        // Extract lat/lng from click event
        final lat = event['latLng']['lat'] as double;
        final lng = event['latLng']['lng'] as double;
        widget.onDestinationSelected!(LatLng(lat, lng));
      }));
    }

    // Add markers if provided
    if (widget.markers != null) {
      for (final marker in widget.markers!) {
        _map!.addMarker(MarkerOptions(
          position: LatLng(marker.position.latitude, marker.position.longitude),
          title: marker.title,
          map: _map,
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!kIsWeb) {
      return const Center(
        child: Text('This widget is for web platform only'),
      );
    }

    return SizedBox(
      key: _mapKey,
      width: double.infinity,
      height: double.infinity,
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Loading map...'),
          ],
        ),
      ),
    );
  }
}

class WebMarker {
  final LatLng position;
  final String title;

  WebMarker({required this.position, required this.title});
}

class LatLng {
  final double latitude;
  final double longitude;

  const LatLng(this.latitude, this.longitude);
}
