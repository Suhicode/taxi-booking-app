import 'package:flutter/material.dart';

class VehicleTile extends StatelessWidget {
  final String vehicleType;
  final bool isSelected;
  final VoidCallback onTap;
  final int estimatedPrice;

  const VehicleTile({
    super.key,
    required this.vehicleType,
    required this.isSelected,
    required this.onTap,
    required this.estimatedPrice,
  });

  IconData _getVehicleIcon() {
    switch (vehicleType.toLowerCase()) {
      case 'bike':
        return Icons.two_wheeler;
      case 'scooty':
        return Icons.two_wheeler;
      case 'standard':
        return Icons.directions_car;
      case 'comfort':
        return Icons.airport_shuttle;
      case 'premium':
        return Icons.directions_car_filled;
      case 'xl':
        return Icons.local_shipping;
      default:
        return Icons.directions_car;
    }
  }

  Color _getVehicleColor() {
    switch (vehicleType.toLowerCase()) {
      case 'bike':
        return Colors.green;
      case 'scooty':
        return Colors.orange;
      case 'standard':
        return Colors.blue;
      case 'comfort':
        return Colors.amber;
      case 'premium':
        return Colors.red;
      case 'xl':
        return Colors.purple;
      default:
        return Colors.blue;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 90,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: isSelected ? _getVehicleColor() : Colors.grey[200],
          borderRadius: BorderRadius.circular(12),
          border: isSelected
              ? Border.all(color: _getVehicleColor(), width: 2)
              : Border.all(color: Colors.grey[300]!, width: 1),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: _getVehicleColor().withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  )
                ]
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              _getVehicleIcon(),
              size: 32,
              color: isSelected ? Colors.white : Colors.grey[600],
            ),
            const SizedBox(height: 8),
            Text(
              vehicleType,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: isSelected ? Colors.white : Colors.grey[600],
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '₹$estimatedPrice',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: isSelected ? Colors.white : Colors.grey[500],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
