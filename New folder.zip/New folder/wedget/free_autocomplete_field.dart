import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../widgets/free_places_service.dart';

typedef FreePlaceCallback = void Function(String name, LatLng location);

class FreeAutocompleteField extends StatefulWidget {
  final String hint;
  final FreePlaceCallback onSelected;
  final TextEditingController? controller;

  const FreeAutocompleteField({
    super.key,
    required this.hint,
    required this.onSelected,
    required this.controller,
  });

  @override
  State<FreeAutocompleteField> createState() => _FreeAutocompleteFieldState();
}

class _FreeAutocompleteFieldState extends State<FreeAutocompleteField> {
  List<FreePlace> _suggestions = [];
  Timer? _debounce;

  void _onChanged(String text) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () async {
      final results = await FreePlacesService.autocomplete(text);
      if (mounted) {
        setState(() => _suggestions = results);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // Ensure controller exists before building
    if (widget.controller == null) {
      return const SizedBox.shrink();
    }
    
    return Column(
      children: [
        TextField(
          controller: widget.controller,
          decoration: InputDecoration(
            hintText: widget.hint,
            prefixIcon: const Icon(Icons.search),
          ),
          onChanged: _onChanged,
        ),
        if (_suggestions.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(top: 4),
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              boxShadow: const [
                BoxShadow(
                  blurRadius: 4,
                  color: Colors.black26,
                ),
              ],
            ),
            child: Column(
              children: _suggestions.map<Widget>((place) {
                return ListTile(
                  title: Text(place.name),
                  onTap: () {
                    widget.controller?.text = place.name;
                    widget.onSelected(place.name, place.location);
                    setState(() => _suggestions = []);
                  },
                );
              }).toList(),
            ),
          ),
      ],
    );
  }
}
