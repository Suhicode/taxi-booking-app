import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:google_maps_flutter/google_maps_flutter.dart';

class FreePlace {
  final String name;
  final LatLng location;

  FreePlace({required this.name, required this.location});
}

class FreePlacesService {
  static Future<List<FreePlace>> autocomplete(String query) async {
    if (query.isEmpty) return [];

    final url = Uri.parse(
        "https://photon.komoot.io/api/?q=$query&limit=8"); // Free API

    final response = await http.get(url);
    if (response.statusCode != 200) return [];

    try {
      final data = jsonDecode(response.body);
      final features = data['features'] as List<dynamic>? ?? [];

      return features.map((f) {
        final props = f['properties'] as Map<String, dynamic>? ?? {};
        final geometry = f['geometry'] as Map<String, dynamic>? ?? {};
        final coords = geometry['coordinates'] as List<dynamic>? ?? [0, 0];

        return FreePlace(
          name: props['name']?.toString() ?? 
                props['city']?.toString() ?? 
                props['country']?.toString() ?? "Unknown",
          location: LatLng(
            coords.length > 1 ? (coords[1] as num).toDouble() : 0.0,
            coords.isNotEmpty ? (coords[0] as num).toDouble() : 0.0,
          ),
        );
      }).toList();
    } catch (e) {
      return [];
    }
  }
}
