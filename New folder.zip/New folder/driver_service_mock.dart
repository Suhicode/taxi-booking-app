// lib/services/driver_service_mock.dart
import 'dart:async';
import 'dart:math';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class DriverModel {
  final String id;
  final String name;
  final LatLng location;
  final String vehicleType;

  DriverModel({required this.id, required this.name, required this.location, required this.vehicleType});

  Marker toMarker() {
    return Marker(
      markerId: MarkerId(id),
      position: location,
      infoWindow: InfoWindow(title: name, snippet: vehicleType),
    );
  }
}

class DriverService {
  // Mock stream that emits a list of driver models every second
  Stream<List<DriverModel>> getAvailableDrivers() async* {
    final rnd = Random();
    final base = LatLng(13.0827, 80.2707);
    while (true) {
      await Future.delayed(const Duration(seconds: 1));
      final drivers = List.generate(3, (i) {
        final lat = base.latitude + (rnd.nextDouble() - 0.5) * 0.02;
        final lng = base.longitude + (rnd.nextDouble() - 0.5) * 0.02;
        return DriverModel(
          id: 'driver_${i + 1}',
          name: ['John Doe', 'Jane Smith', 'Mike Johnson'][i % 3],
          location: LatLng(lat, lng),
          vehicleType: ['Standard', 'Premium', 'Comfort'][i % 3],
        );
      });
      yield drivers;
    }
  }
}
